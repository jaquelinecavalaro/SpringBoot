package com.hellowordwonderful.hellowonderful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellowonderfulApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellowonderfulApplication.class, args);
	}

}
