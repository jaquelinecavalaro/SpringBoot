package com.hellowordwonderful.hellowonderful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellowonderfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
